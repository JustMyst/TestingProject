﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BookLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace BookLibrary.Tests
{
    [TestClass()]
    public class Form1Tests
    {
        string bookName;
        string author;
        string genre;
        Form1 form;

        [TestInitialize()]
        public void prepareVariables()
        {
            form = new Form1();
        }

        [TestMethod()] 
        public void addItemWithBlankParameterReturnsError()
        {
            bookName = "";
            author = "author";
            genre = "genre";
            bool validation = form.AddItem(bookName, author,  genre);
            Assert.AreEqual(validation, false);
        }
        [TestMethod()]
        public void addItemWithGoodParametersReturnsTrue()
        {
            bookName = "bookName";
            author = "author";
            genre = "book";

            bool validation = form.AddItem(bookName, author, genre);

            Assert.AreEqual(validation, true);
        }

        [TestMethod()]
        public void startEditingTest()
        {
            string itemToEdit = "itemToEdit";
            string validation = form.EditItem(itemToEdit);
            Assert.AreEqual(validation, "Item beeing modified");
        }


    }
}