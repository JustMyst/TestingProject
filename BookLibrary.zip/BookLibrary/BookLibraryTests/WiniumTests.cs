﻿using System;
using System.Collections.Generic;
using System.Threading;
using BookLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Winium;

namespace BookLibraryTests
{
    [TestClass]
    public class WiniumTest
    {

        private readonly WiniumDriver driver;
        public WiniumTest()
        {
            DesktopOptions options = new DesktopOptions();
            string path = System.IO.Path.GetDirectoryName(typeof(Form1).Assembly.Location);
            options.ApplicationPath = path + @"\BookLibrary.exe";
            driver = new WiniumDriver(path, options);
        }
        [TestMethod]
        public void addItemWithProperFieldsCreatesItem()
        {
            addItem(driver);
            driver.Close();
        }

        [TestMethod()]
        public void createItemWithEmptyFieldReturnsError()
        {
            driver.FindElementByName("addItem").Click();
            Equals(true, driver.FindElementByName("Some fields are missing."));
            driver.FindElementByName("Close").Click();
            driver.Close();
        }

        [TestMethod()]
        public void deleteNotSelectedItemReturnsError()
        {

            driver.FindElementByName("deleteItem").Click();
            Equals(true, driver.FindElementByName("Item not selected."));
            driver.FindElementByName("Close").Click();
            driver.Close();
        }

        public void addItem(WiniumDriver driver)
        {
            Thread.Sleep(3000);
            driver.FindElementByName("bookName").SendKeys("name");
            driver.FindElementByName("author").SendKeys("author");
            driver.FindElementByName("addItem").Click();
            Equals(true, driver.FindElementByName("name by author"));
        }


    }
}
