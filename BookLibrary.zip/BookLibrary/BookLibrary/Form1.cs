﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;


namespace BookLibrary
{
    public partial class Form1 : Form
    {
        List<Book> listOfBooks = new List<Book>();
        private int editedElement;
        public Form1()
        {
            listOfBooks.Add(new Book("Czarny pryzmat", "Brent Weeks", "fantasy"));
            listOfBooks.Add(new Book("Pan Lodowego Ogrodu","Jarosław Grzędowicz", "fantasy"));
            InitializeComponent();
            saveButton.Enabled = false;
            for (int i = 0; i < listOfBooks.Count; i++)
                bookList.Items.Add(listOfBooks[i].Name);
        }

       
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string message = "Some fields are missing.";
            string caption = "Error!";
            string bookName = bookNameTextBox.Text;
            string author = authorTextBox.Text;
            string genre = genreTextBox.Text;
            MessageBoxButtons messageBoxButtons = MessageBoxButtons.OK;
            bool isTrue = AddItem(bookName, author,genre);
            if(!isTrue)
                MessageBox.Show(message, caption, messageBoxButtons);
            bookNameTextBox.Clear();
            authorTextBox.Clear();

        }

        public bool AddItem(string bookName, string author,  string genre)
        {
            if (bookName.Length == 0 ||  author.Length == 0)
            {
                return false;
            }
            else
            {
                Book book = new Book( bookName,author, genre);
                listOfBooks.Add(book);
                bookList.Items.Clear();
                for (int i = 0; i < listOfBooks.Count; i++)
                    bookList.Items.Add(listOfBooks[i].Name + " by " +listOfBooks[i].Author);
                return true;
            }
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            try
            {
                string ItemToRemove = bookList.SelectedItem.ToString();
                for (int i = bookList.Items.Count - 1; i >= 0; i--)
                {
                    if (bookList.Items[i].ToString().Contains(ItemToRemove))
                    {
                        bookList.Items.RemoveAt(i);
                        for (int j = 0; j < listOfBooks.Count; j++)
                        {
                            if (listOfBooks[j].Name == ItemToRemove)
                            {
                                listOfBooks.RemoveAt(j);
                                saveButton.Enabled = false;
                                bookList.Enabled = true;
                                addButton.Enabled = true;
                            }
                        }
                    }
                }
            }catch(NullReferenceException ex)
            {
                string message = "Item not selected.";
                string caption = "Error!";
                MessageBoxButtons messageBoxButtons = MessageBoxButtons.OK;

                DialogResult result;
                result = MessageBox.Show(message, caption, messageBoxButtons);
            }
        }

        private void bookList_DoubleClick(object sender, System.EventArgs e)
        {
            if (bookList.SelectedItem != null)
            {
                try
                {
                    string toEditItem = bookList.SelectedItem.ToString();
                    EditItem(toEditItem);
                }
                catch (NullReferenceException ex)
                {
                    string message = "Item not selected.";
                    string caption = "Error!";
                    MessageBoxButtons messageBoxButtons = MessageBoxButtons.OK;
                    DialogResult result;
                    result = MessageBox.Show(message, caption, messageBoxButtons);
                }
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            genreTextBox.SelectedItem = null;
            genreTextBox.SelectedText = "other";
        }

        public String EditItem(string toEditItem)
        {
            for (int i = 0; i < listOfBooks.Count; i++)
            {
                if (listOfBooks[i].Name == toEditItem)
                {
                    Book edited = listOfBooks[i];
                    bookNameTextBox.Text = edited.Name;
                    authorTextBox.Text = edited.Author;
                    genreTextBox.Text = edited.Genre;
                    editedElement = i;
                }
            }
            saveButton.Enabled = true;
            addButton.Enabled = false;
            bookList.Enabled = false;
            return "Item beeing modified";
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            listOfBooks[editedElement].Name = bookNameTextBox.Text;
            listOfBooks[editedElement].Author = authorTextBox.Text;
            listOfBooks[editedElement].Genre = genreTextBox.Text;

            bookNameTextBox.Clear();
            authorTextBox.Clear();

            saveButton.Enabled = false;
            bookList.Enabled = true;
            addButton.Enabled = true;
        }

        private void bookNameTextBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
