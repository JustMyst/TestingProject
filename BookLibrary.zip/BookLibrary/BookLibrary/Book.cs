﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookLibrary
{
    public class Book
    {
        private string name;
        private string author;
        private string genre;

        public Book( string name, string author, string genre)
        {
            this.Name = name;
            this.Author = author;
            this.Genre = genre;
        }

        public string Name { get { return name; } set { name = value; } }
        public string Author { get { return author; } set { author = value; } }
        public string Genre { get { return genre; } set { genre = value; } }
    }
}
